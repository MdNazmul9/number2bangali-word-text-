# number2bangali_word_text
```
pip install numberbanglaword

from numberbanglaword import to_bn_word

to_bn_word(12054470.456)
```